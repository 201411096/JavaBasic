package b_operator;

public class Ex11 {

	public static void main(String[] args) {
		
		int  z = 10 - 7 ^ 3 + 1 * 2 & 4; // 3^3 + 2&4 -> 3^5&4 // 101 100  011^100->111 
		System.out.println(z);

	}

}
