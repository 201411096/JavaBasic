package temp;

public class temp {

	public static void main(String[] args) {
		int n=1;
		while(true)
		{
			System.out.println(n);	
			if(n==200)
				break;
			n++;
		}
	}
}
