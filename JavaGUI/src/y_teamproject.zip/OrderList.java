package y_teamproject;

import java.util.ArrayList;

public class OrderList {
	ArrayList<Menu> orderList;
	
	public OrderList(){
		orderList = new ArrayList<Menu>();
	}
	
	public void addMenu(Menu menu) {
		orderList.add(menu);
	}
	public void deleteMenu(Menu menu) {
		orderList.remove(menu);
	}
	
	public String toString() {
		String s="";
		for(int i=0; i<orderList.size(); i++)
			s+=orderList.get(i).name+ " " + orderList.get(i).cost+"\n";
		
		return s;
	}
	
}
