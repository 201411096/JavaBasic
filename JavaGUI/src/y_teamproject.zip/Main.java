package y_teamproject;

public class Main {

	public static void main(String[] args) {
		MainFrame m = new MainFrame();
		m.display();
		m.eventConn();
	}
}
