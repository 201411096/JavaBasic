package y_teamproject;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JPanel;

public class SideMenuPanel extends JPanel{
	ImageIcon imageIconArray [] = new ImageIcon[4];
	JButton buttonArray [] =new JButton[4];
	public SideMenuPanel() {
		setPreferredSize(new Dimension(1500, 1080));
		setBackground(Color.orange);

		setLayout(new GridLayout(2,2));
		imageIconArray[0] = new ImageIcon("src/y_teamproject/imgs/side1.png");
		imageIconArray[1] = new ImageIcon("src/y_teamproject/imgs/side2.png");
		imageIconArray[2] = new ImageIcon("src/y_teamproject/imgs/side3.png");
		imageIconArray[3] = new ImageIcon("src/y_teamproject/imgs/side4.png");


		for(int i=0; i<imageIconArray.length; i++)
		{
			buttonArray[i] = new JButton(imageIconArray[i]);
			buttonArray[i].setBackground(Color.white);
			add(buttonArray[i]);
		}

		setPreferredSize(new Dimension(1500, 1080));
	}
}
