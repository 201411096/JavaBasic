package y_teamproject;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JPanel;

public class MainMenuPanel extends JPanel{
	 ImageIcon imageIconArray [] = new ImageIcon[4];
	 JButton buttonArray [] =new JButton[4];
	 
	public MainMenuPanel() {
		setLayout(new GridLayout(2,2));
		imageIconArray[0] = new ImageIcon("src/y_teamproject/imgs/main1.png");
		imageIconArray[1] = new ImageIcon("src/y_teamproject/imgs/main2.png");
		imageIconArray[2] = new ImageIcon("src/y_teamproject/imgs/main3.png");
		imageIconArray[3] = new ImageIcon("src/y_teamproject/imgs/main4.png");
		
		for(int i=0; i<imageIconArray.length; i++)
		{
			buttonArray[i] = new JButton(imageIconArray[i]);
			buttonArray[i].setBackground(Color.white);
			add(buttonArray[i]);
		}

			
		setPreferredSize(new Dimension(1500, 1080));
	}
}
