package y_teamproject;

import java.awt.Color;
import java.awt.Dimension;

import javax.swing.JPanel;

public class OrderPanel extends JPanel {
	public OrderPanel() {
		setPreferredSize(new Dimension(420, 1080));
		setBackground(Color.blue);
	}
}
