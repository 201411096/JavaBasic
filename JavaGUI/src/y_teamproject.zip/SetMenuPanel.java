package y_teamproject;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JPanel;

public class SetMenuPanel extends JPanel{
	ImageIcon imageIconArray [] = new ImageIcon[4];
	JButton buttonArray [] =new JButton[4];
	public SetMenuPanel() {
		setPreferredSize(new Dimension(1500, 1080));
		setBackground(Color.green);

		setLayout(new GridLayout(2,2));
		imageIconArray[0] = new ImageIcon("src/y_teamproject/imgs/setA.png");
		imageIconArray[1] = new ImageIcon("src/y_teamproject/imgs/setB.png");
		imageIconArray[2] = new ImageIcon("src/y_teamproject/imgs/setC.png");
		imageIconArray[3] = new ImageIcon("src/y_teamproject/imgs/setD.png");


		for(int i=0; i<imageIconArray.length; i++)
		{
			buttonArray[i] = new JButton(imageIconArray[i]);
			buttonArray[i].setBackground(Color.white);
			add(buttonArray[i]);
		}

		setPreferredSize(new Dimension(1500, 1080));
	}
}
